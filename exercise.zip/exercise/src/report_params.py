

def gen_params(a, b) -> list[str]:
    #Splitting the inputs and converting them to the lower case
    a_inputs=set(a.lower().split(','))
    b_inputs=set(b.lower().split())
    
    #Common elements
    common_elements=a_inputs.intersection(b_inputs)

    return list(common_elements)
