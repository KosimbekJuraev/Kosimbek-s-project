import unittest
import sys
sys.path.append('/Users/kosimbek/Downloads/exercise')
from src.report_params import gen_params

class TestReportParams(unittest.TestCase):
    def test(self):
        a = "Dog,caTfish,Frog,FIsh,apple  ,    Monkey,appLe,fox"
        b = "Frog  apple    fox cat fish fish"
        expected_result = ['apple', 'fox', 'fish', 'frog']
        result = gen_params(a, b)
        self.assertListEqual(sorted(result), sorted(expected_result))

    def test_partial_matches(self):
        a = "Dog,caTfish,Frog,FIsh,apple  ,    Monkey,appLe,fox"
        b = "Frog  apple    fox catfish fish"
        expected_result = ['apple', 'frog', 'fish', 'catfish','fox']
        result = gen_params(a, b)
        self.assertListEqual(sorted(result), sorted(expected_result))

if __name__ == '__main__':
    unittest.main()

